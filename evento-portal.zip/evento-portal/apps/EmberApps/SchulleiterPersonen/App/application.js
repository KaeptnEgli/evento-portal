﻿define([
], function () {

    var app = {
        rootElement: '#CLX_Root',
    };
    return app;
});
