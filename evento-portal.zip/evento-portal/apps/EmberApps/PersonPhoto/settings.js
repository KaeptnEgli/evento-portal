// Rename this file to settings.js and adjust the settings
window.personPhoto = window.personPhoto || {};
window.personPhoto.settings = {
  /**
   * General settings
   */
  // API base URL without trailing slash
  apiUrl: window.parent.eventoPortal.settings.apiServer,
  moduleDir: '../PersonPhoto'

};
