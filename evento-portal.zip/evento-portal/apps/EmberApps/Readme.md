Grundsätzlich gelten die Dokumentationen gemäss aktueller Version von Swiss Learning Hub.

In den blau markierten Verzeichnissen und Dateien von ..\JSModules dürfen wir Änderungen vornehmen. Die detaillierten Konfigurationen sind immer auf dem Lib-Share im Verzeichnis "MASTER-Web_Bedag" aktuell

![image](https://user-images.githubusercontent.com/41326409/146224629-3a1478fb-8601-4871-bfd4-57caa0096cf3.png)
