﻿define({
    paths: {
        'appConfig': 'appConfig',
        'main_settings': 'settings',

    }
});
